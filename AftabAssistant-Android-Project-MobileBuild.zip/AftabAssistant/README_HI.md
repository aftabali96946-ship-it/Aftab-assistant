# Aftab Assistant — Android starter project

यह Android Studio के लिए Kotlin + Jetpack Compose starter project है। इसमें Black & Gold UI, chat demo, Android speech recognition (फोन पर उपलब्ध होने पर), और Text-to-Speech शामिल हैं।

## अभी क्या काम करता है
- ऐप की शुरुआती स्क्रीन और चैट UI
- सीमित demo replies (यह अभी असली ChatGPT नहीं है)
- Voice typing के लिए Android speech recognizer
- जवाब को आवाज़ में सुनना
- Photo / Video / Search tabs का शुरुआती UI

## अभी क्या जोड़ना बाकी है
- असली AI chat के लिए server/backend और AI provider API
- Image generation/editing provider
- Live web search provider
- API keys को सुरक्षित रखने वाला backend

## APK बनाने का तरीका
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. Android Studio में `AftabAssistant` फ़ोल्डर खोलें।
3. Gradle sync पूरा होने दें और ज़रूरत पड़े तो Android SDK 35 इंस्टॉल करें।
4. फोन में Developer options और USB debugging चालू करके Run करें, या Build > Build APK(s) चुनें।
5. Debug APK आम तौर पर `app/build/outputs/apk/debug/app-debug.apk` में बनती है।

ध्यान दें: इस वातावरण में Android SDK/Gradle build उपलब्ध नहीं था, इसलिए यहाँ तैयार APK नहीं बनी है। यह source project है; AI और live search सुविधाएँ API जोड़ने के बाद ही वास्तविक रूप से काम करेंगी। API key को सीधे Android app में न रखें।

## केवल Android फोन से APK बनाना (GitHub Actions)
1. ZIP को डाउनलोड करके Extract करें।
2. GitHub पर नया repository बनाएँ और Extract किए हुए फ़ोल्डर की सभी फ़ाइलें अपलोड करें (मुख्य फ़ोल्डर के अंदर की फ़ाइलें, जिनमें `.github` भी है)।
3. Repository में Actions टैब खोलें। `Build Aftab Assistant APK` workflow चुनकर `Run workflow` दबाएँ।
4. Build सफल होने पर workflow run खोलें और नीचे `Artifacts` से `AftabAssistant-debug-apk` डाउनलोड करें।
5. ZIP को Extract करें, APK पर टैप करें और Android के निर्देशों के अनुसार install करें। केवल भरोसेमंद स्रोत से बनी APK इंस्टॉल करें।

यह workflow APK बनाने की कोशिश करता है; build सफल होगा इसकी गारंटी नहीं है। मौजूदा ऐप demo है—असली AI chat, image generation और live web search के लिए backend/API जोड़ना बाकी है।
