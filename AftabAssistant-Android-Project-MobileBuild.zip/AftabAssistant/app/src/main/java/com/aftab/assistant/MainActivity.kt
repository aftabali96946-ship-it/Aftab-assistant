package com.aftab.assistant

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Gold = Color(0xFFFFC857)
private val Ink = Color(0xFF101014)
private val Panel = Color(0xFF1D1D24)
private data class ChatLine(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN") }
        setContent { AftabApp(onSpeak = { tts?.speak(it, TextToSpeech.QUEUE_FLUSH, null, "aftab-reply") }) }
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AftabApp(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("Chat") }
    val messages = remember { mutableStateListOf(ChatLine("नमस्ते! मैं Aftab Assistant हूँ। आप मुझसे हिंदी या English में सवाल पूछ सकते हैं।", false)) }
    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Ink, surface = Panel)) {
        Scaffold(containerColor = Ink, topBar = {
            Column(Modifier.fillMaxWidth().background(Panel).padding(18.dp)) {
                Text("✦ AFTAB ASSISTANT", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text("आपका स्मार्ट AI साथी", color = Color.LightGray, fontSize = 13.sp)
            }
        }, bottomBar = {
            Column(Modifier.fillMaxWidth().background(Panel).padding(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf("Chat", "Photo", "Video", "Search").forEach { name ->
                        FilterChip(selected = tab == name, onClick = { tab = name }, label = { Text(name) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold, selectedLabelColor = Ink))
                    }
                }
                if (tab == "Chat") {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("अपना सवाल लिखें...") }, shape = RoundedCornerShape(18.dp), singleLine = true)
                        IconButton(onClick = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए")
                            }
                            try { voiceLauncher.launch(intent) } catch (_: Exception) { messages.add(ChatLine("इस मोबाइल में voice typing उपलब्ध नहीं है।", false)) }
                        }) { Text("🎙️", fontSize = 22.sp) }
                        Button(onClick = {
                            val q = input.trim()
                            if (q.isNotEmpty()) {
                                messages.add(ChatLine(q, true))
                                val answer = basicReply(q)
                                messages.add(ChatLine(answer, false)); input = ""
                            }
                        }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink), contentPadding = PaddingValues(horizontal = 14.dp)) { Text("➤") }
                    }
                } else {
                    Text(when(tab) {
                        "Photo" -> "AI Photo: फोटो बनाने या एडिट करने के लिए अपना निर्देश लिखें। इस starter app में अभी image-generation API जोड़नी बाकी है।"
                        "Video" -> "AI Video: नीचे Chat में अपना विषय लिखें और ‘वीडियो प्रॉम्प्ट बनाओ’ कहें।"
                        else -> "Internet Search: लाइव सर्च सुविधा चालू करने के लिए सुरक्षित search API/backend जोड़ना होगा।"
                    }, color = Color.White, modifier = Modifier.padding(8.dp), fontSize = 13.sp)
                }
            }
        }) { padding ->
            if (tab == "Chat") {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp), contentPadding = PaddingValues(vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(messages) { line ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                            Surface(color = if (line.fromUser) Gold else Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 320.dp)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(if (line.fromUser) "आप" else "Aftab AI", color = if (line.fromUser) Ink else Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Spacer(Modifier.height(4.dp))
                                    Text(line.text, color = if (line.fromUser) Ink else Color.White)
                                    if (!line.fromUser) TextButton(onClick = { onSpeak(line.text) }, contentPadding = PaddingValues(0.dp)) { Text("🔊 जवाब सुनें", color = Gold, fontSize = 12.sp) }
                                }
                            }
                        }
                    }
                }
            } else {
                Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(when(tab) { "Photo" -> "🖼️"; "Video" -> "🎬"; else -> "🌐" }, fontSize = 52.sp)
                    Spacer(Modifier.height(12.dp)); Text(tab, color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("यह सुविधा AI provider/API जोड़ने के बाद काम करेगी।", color = Color.White)
                    Spacer(Modifier.height(10.dp)); Button(onClick = { tab = "Chat" }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) { Text("Chat पर जाएँ") }
                }
            }
        }
    }
}

private fun basicReply(q: String): String {
    val s = q.lowercase(Locale.ROOT)
    return when {
        "video prompt" in s || "वीडियो प्रॉम्प्ट" in s || "वीडियो prompt" in s -> "आपके वीडियो के लिए प्रॉम्प्ट: सिनेमैटिक 4K, realistic lighting, smooth camera movement, natural expressions, detailed background, vertical 9:16. अपना विषय बताइए ताकि इसे खास बनाया जा सके।"
        "photo" in s || "फोटो" in s -> "फोटो एडिट के लिए बताइए: बैकग्राउंड बदलना है, कपड़े बदलने हैं, क्वालिटी बढ़ानी है या सिनेमैटिक लुक चाहिए? वास्तविक AI editing के लिए image API जोड़नी होगी।"
        "hello" in s || "नमस्ते" in s || "हेलो" in s -> "नमस्ते! बताइए, मैं आपकी क्या मदद करूँ?"
        "time" in s || "समय" in s -> "अपने मोबाइल की घड़ी में सही स्थानीय समय देख सकते हैं।"
        else -> "आपका सवाल मिला: ‘$q’। यह शुरुआती demo है, इसलिए अभी सीमित जवाब देता है। ChatGPT-जैसे असली AI जवाबों के लिए सुरक्षित backend और AI API key जोड़नी होगी। API key ऐप के अंदर सीधे न रखें।"
    }
}
